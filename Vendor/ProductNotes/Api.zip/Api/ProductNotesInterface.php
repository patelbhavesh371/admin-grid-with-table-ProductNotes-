<?php

namespace Vendor\ProductNotes\Api;

interface ProductNotesInterface
{
    public function getNotes(int $productId);
}
