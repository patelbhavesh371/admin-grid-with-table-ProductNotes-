<?php

namespace Vendor\ProductNotes\Api\Data;

interface ProductNotesResponseInterface
{
    public function getProductId();
    public function setProductId($productId);

    /**
     * @return \Vendor\ProductNotes\Api\Data\NoteInterface[]
     */
    public function getNotes();

    /**
     * @param \Vendor\ProductNotes\Api\Data\NoteInterface[] $notes
     */
    public function setNotes(array $notes);
}
