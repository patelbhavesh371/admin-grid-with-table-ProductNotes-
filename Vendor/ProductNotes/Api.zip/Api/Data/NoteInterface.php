<?php

namespace Vendor\ProductNotes\Api\Data;

interface NoteInterface
{
    public function getTitle();
    public function setTitle($title);

    public function getDetails();
    public function setDetails($details);
}
